/**
 * Email Briefing Tool - Main Application Controller
 * Version: 5.0 - Firebase Integration
 * Last Updated: November 2025
 * 
 * FIX: Unified global formData to prevent "Cannot set properties of undefined" errors
 */

// ============================================
// APPLICATION STATE - GLOBAL UNIFIED STATE
// ============================================

// CRITICAL FIX: Initialize as window properties FIRST for global access
window.formData = window.formData || {};
window.uploadedImages = window.uploadedImages || {};

// Create local references that point to the same objects
let currentTemplate = null;
let currentTemplateKey = null;
let formData = window.formData;
let uploadedImages = window.uploadedImages;

// Flag to distinguish between loading a fresh template vs a saved design
let isLoadingSavedDesign = false;
let savedDesignName = null;
let savedDesignTemplateName = null;

// TASK I: Builder mode flag to differentiate Template Mode vs Design Mode
window.builderMode = 'template'; // Can be 'template' or 'design'

// ============================================
// INITIALIZATION
// ============================================

async function init() {
    // Firebase auto-connects, no initialization needed
    console.log('✓ Database initialized successfully');
    
    setupEventListeners();
    
    // Load template from URL or sessionStorage
    const params = new URLSearchParams(window.location.search);
    const keyFromUrl = params.get("template") || sessionStorage.getItem("selectedTemplateKey");
    
    if (keyFromUrl) {
        window.loadTemplateByKey(keyFromUrl);
    }
}

function setupEventListeners() {
    document.getElementById("save-btn").addEventListener("click", handleSave);
    
    // Add Save As button handler
    const saveAsBtn = document.getElementById("save-as-btn");
    if (saveAsBtn) {
        saveAsBtn.addEventListener("click", handleSaveAs);
    }
    
    // Add Copy Link button handler
    const copyLinkBtn = document.getElementById("copy-link-btn");
    if (copyLinkBtn) {
        copyLinkBtn.addEventListener("click", copyShareableLink);
    }
    
    document.getElementById("load-file-input").addEventListener("change", loadProject);
    document.getElementById("export-btn").addEventListener("click", showExportModal);
    document.getElementById("desktop-view").addEventListener("click", switchToDesktop);
    document.getElementById("mobile-view").addEventListener("click", switchToMobile);
    
    const creativeDropdown = document.getElementById("creative-direction-top");
    if(creativeDropdown) {
        creativeDropdown.addEventListener("change", (e) => {
            window.formData["creative-direction"] = e.target.value;
        });
    }
}

// ============================================
// TEMPLATE HANDLING
// ============================================

window.loadTemplateByKey = function(templateKey) {
    console.log("🔍 loadTemplateByKey called with:", templateKey);
    
    // Normalize and validate the key
    const key = (templateKey || "").trim();
    if (!key) {
        console.error("❌ loadTemplateByKey: Empty or invalid template key provided");
        return;
    }
    
    // Try multiple possible template source locations
    const allTemplates = window.templates || window.templateDefinitions || {};
    console.log("📚 Available template sources:", {
        "window.templates": !!window.templates,
        "window.templateDefinitions": !!window.templateDefinitions,
        "using": allTemplates === window.templates ? "window.templates" : "window.templateDefinitions"
    });
    
    // Check if template exists
    if (!allTemplates[key]) {
        console.error("❌ Template not found:", key);
        console.log("📋 Available template keys:", Object.keys(allTemplates));
        console.log("💡 Did you mean one of these?", Object.keys(allTemplates).filter(k => 
            k.toLowerCase().includes(key.toLowerCase()) || 
            key.toLowerCase().includes(k.toLowerCase())
        ));
        return;
    }
    
    // Template found - proceed with loading
    console.log("✅ Template found:", key);
    const templateDefinition = allTemplates[key];
    console.log("📄 Template details:", {
        name: templateDefinition.name,
        fields: templateDefinition.fields ? templateDefinition.fields.length : 0,
        type: templateDefinition.type || "unknown"
    });
    
    // --- Global state sync (critical) ---
    currentTemplateKey = key;
    currentTemplate = templateDefinition;
    
    // Mirror to window for debugging / external tools
    window.currentTemplateKey = currentTemplateKey;
    window.currentTemplate = currentTemplate;
    
    // CRITICAL FIX: Clear global state objects without reassigning references
    Object.keys(window.formData).forEach(key => delete window.formData[key]);
    Object.keys(window.uploadedImages).forEach(key => delete window.uploadedImages[key]);
    console.log("🔄 State reset: formData and uploadedImages cleared");
    
    // TASK I: Set builder mode to 'template' and update header
    window.builderMode = 'template';
    updateBuilderHeader({
        mode: 'template',
        templateName: templateDefinition.name || key
    });
    
    // Pass template key and definition directly to generateForm
    if (typeof window.generateForm === "function") {
        console.log("📝 Calling generateForm() with templateKey and definition...", {
            templateKey: key,
            hasDefinition: !!templateDefinition,
            fieldCount: templateDefinition && templateDefinition.fields ? templateDefinition.fields.length : 0
        });
        window.generateForm(key, templateDefinition);
    } else {
        console.warn("⚠️ generateForm function not found");
    }
    
    if (typeof window.updatePreview === "function") {
        console.log("🖼️ Calling updatePreview()...");
        window.updatePreview();
    } else {
        console.warn("⚠️ updatePreview function not found");
    }
    
    console.log("✅ loadTemplateByKey completed successfully");
};

// ============================================
// HELPER FUNCTIONS
// ============================================

// TASK I: Unified builder header update function
function updateBuilderHeader({ mode, templateName, designName }) {
    try {
        const titleEl = document.getElementById('builder-template-title');
        const projectInfoDisplay = document.getElementById('project-info-display');
        const projectNameDisplay = document.getElementById('project-name-display');
        
        // Safety check: ensure all elements exist
        if (!titleEl) {
            console.warn('⚠️ updateBuilderHeader: builder-template-title element not found');
            return;
        }
        
        if (mode === 'template') {
            // Template Mode: Show template name as main title, hide subtitle
            titleEl.textContent = templateName || 'Your Content';
            
            if (projectInfoDisplay) {
                projectInfoDisplay.style.display = 'none';
            }
            
            console.log('✅ Builder header set to Template Mode:', templateName);
            
        } else if (mode === 'design') {
            // Design Mode: Show design name as main title, template name as subtitle
            titleEl.textContent = designName || templateName || 'Your Content';
            
            if (projectInfoDisplay && projectNameDisplay && templateName) {
                projectNameDisplay.textContent = templateName;
                projectInfoDisplay.style.display = 'flex';
                console.log('✅ Builder header set to Design Mode:', designName, '→', templateName);
            } else if (projectInfoDisplay) {
                // Hide subtitle if template name is missing
                projectInfoDisplay.style.display = 'none';
                console.warn('⚠️ Template name missing in Design Mode, hiding subtitle');
            }
        }
    } catch (err) {
        console.error('❌ Failed to update builder header:', err);
    }
}

// Expose updateBuilderHeader globally for use in other modules
window.updateBuilderHeader = updateBuilderHeader;

// Legacy function - now redirects to updateBuilderHeader
function updateBuilderTemplateTitle(templateKey, templateDefinition) {
    const templateName = templateDefinition?.name || 
                        (window.templates && templateKey ? window.templates[templateKey]?.name : null) || 
                        templateKey?.replace(/-/g, ' ') || 
                        'Your Content';
    
    updateBuilderHeader({
        mode: 'template',
        templateName: templateName
    });
}

// ============================================
// INITIALIZE APP ON LOAD
// ============================================
document.addEventListener('DOMContentLoaded', init);
