// Export-related functions for Email Briefing App
// Handles Excel, HTML, PDF exports and download functionality
// PHASE 4 TASK K: Updated to reuse preview HTML and bundle static assets

// ============================================
// EXPORT MODAL FUNCTIONS
// ============================================

function openExportModal() {
    const modal = document.getElementById('export-modal');
    if (modal) {
        // Populate folder hierarchy for export
        populateFolderHierarchyExport();
        modal.classList.add('active');
    }
}

function closeExportModal() {
    const modal = document.getElementById('export-modal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// ============================================
// PHASE 4 TASK K2: STATIC ASSETS COLLECTION
// ============================================

/**
 * Get file extension from path or URL
 * @param {string} path - File path or URL
 * @returns {string} Extension with dot (e.g., ".png")
 */
function getExtensionFromPath(path) {
    const match = /\.(\w+)(?:$|\?)/.exec(path || '');
    return match ? '.' + match[1] : '';
}

/**
 * Generate export filename for an image entry
 * @param {Object} entry - Image entry with sourceType and key
 * @param {string} entry.sourceType - 'uploaded' or 'static'
 * @param {string} entry.key - Image identifier
 * @param {string} entry.src - Image source path
 * @returns {string} Filename for use in ZIP
 */
function makeExportFileName(entry) {
    const ext = getExtensionFromPath(entry.src) || '.png';
    if (entry.sourceType === 'static') {
        return `static-${entry.key || 'asset'}${ext}`;
    }
    return `${entry.key || 'image'}${ext}`;
}

/**
 * Collect all static assets defined in current template
 * @returns {Array} Array of static asset entries
 */
function collectStaticAssets() {
    const activeTemplateKey = window.currentTemplateKey || null;
    if (!activeTemplateKey) {
        console.log('📦 No active template, skipping static assets');
        return [];
    }
    
    const template = templates[activeTemplateKey];
    if (!template || !template.staticAssets) {
        console.log('📦 Template has no staticAssets defined');
        return [];
    }
    
    const assets = [];
    template.staticAssets.forEach(asset => {
        if (asset.export) {
            assets.push({
                sourceType: 'static',
                key: asset.id,
                src: asset.src
            });
        }
    });
    
    console.log(`📦 Collected ${assets.length} static assets from template:`, assets.map(a => a.src));
    return assets;
}

// ============================================
// MAIN EXPORT FUNCTION (ZIP PACKAGE)
// ============================================

async function exportAsExcel() {
    if (!currentTemplate) {
        alert("Please select a template first");
        closeExportModal();
        return;
    }

    console.log("=== Starting Export (Task K) ===");

    // Use current project name exactly as it is
    const projectName = window.currentProjectName || "email-brief";

    const zip = new JSZip();
    
    // ============================================
    // 1. CREATE EXCEL FILE (Content Brief)
    // ============================================
    console.log("Creating Excel file...");
    let excelContent = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
        th { background-color: #351F65; color: white; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>
    <h1>Email Content Brief - ${projectName}</h1>
    <table>
        <tr>
            <th>Field</th>
            <th>Content</th>
            <th>Character Count</th>
            <th>Max Characters</th>
        </tr>`;

    const imagesFolder = zip.folder("images");

    // Export creative direction
    const creativeDirectionValue = document.getElementById("creative-direction-top").value;
    if (creativeDirectionValue && creativeDirectionValue !== "[Choose one]") {
        excelContent += `
        <tr>
            <td><strong>I need the creative team to...</strong></td>
            <td>${creativeDirectionValue}</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>`;
    }

    currentTemplate.fields.forEach(field => {
        const value = formData[field.id] || "";
        const elem = document.getElementById(field.id);
        const charCount = elem && elem.contentEditable === "true" ?
            elem.textContent.length :
            value.length;
        const maxChars = field.maxChars || "N/A";

        excelContent += `<tr><td><strong>${field.label}</strong></td>`;

        if (field.type === "image") {
            if (uploadedImages[field.id]) {
                const imageData = uploadedImages[field.id];
                const imageExtension = imageData.substring(imageData.indexOf("/") + 1, imageData.indexOf(";"));
                const imageName = `${field.label.replace(/[^a-z0-9]/gi, "_")}.${imageExtension}`;
                const base64Data = imageData.split(",")[1];
                imagesFolder.file(imageName, base64Data, { base64: true });
                excelContent += `<td>See: images/${imageName}</td>`;
            } else {
                excelContent += `<td>[No image uploaded]</td>`;
            }
            excelContent += `<td>N/A</td><td>N/A</td>`;
        } else {
            // Export with HTML formatting preserved
            const displayValue = value;
            excelContent += `<td>${displayValue}</td><td>${charCount}</td><td>${maxChars}</td>`;
        }

        excelContent += `</tr>`;
    });

    excelContent += `
    </table>
</body>
</html>`;

    zip.file(projectName + ".xls", excelContent);
    console.log("Excel file created");

    // ============================================
    // PHASE 4 TASK K2: COLLECT ALL IMAGES
    // ============================================
    
    console.log("📦 Task K2: Collecting images for export...");
    const allImages = [];
    
    // 1. User-uploaded images (existing behavior)
    for (const [slotKey, imageUrl] of Object.entries(uploadedImages || {})) {
        if (!imageUrl) continue;
        allImages.push({
            sourceType: 'uploaded',
            key: slotKey,
            src: imageUrl
        });
    }
    
    // 2. Static assets from template definition (NEW)
    const staticAssets = collectStaticAssets();
    allImages.push(...staticAssets);
    
    // Log summary
    console.log('🖼 Export images summary:', {
        uploaded: allImages.filter(i => i.sourceType === 'uploaded').length,
        static:   allImages.filter(i => i.sourceType === 'static').length,
        total:    allImages.length
    });
    
    // ============================================
    // BUNDLE IMAGES INTO ZIP
    // ============================================
    
    for (const entry of allImages) {
        try {
            const filename = makeExportFileName(entry);
            console.log(`📥 Fetching ${entry.sourceType} image: ${entry.src} → ${filename}`);
            
            // Handle both relative paths (local assets) and URLs (uploaded images)
            let response;
            if (entry.src.startsWith('http') || entry.src.startsWith('data:')) {
                // Remote URL or data URL
                response = await fetch(entry.src);
            } else {
                // Relative path - fetch as-is
                response = await fetch(entry.src);
            }
            
            if (!response.ok) {
                console.error(`⚠️ Failed to fetch ${entry.src}: ${response.statusText}`);
                continue;
            }
            
            const blob = await response.blob();
            imagesFolder.file(filename, blob);
            console.log(`✅ Added ${filename} to ZIP (${blob.size} bytes)`);
            
        } catch (err) {
            console.error(`❌ Error adding ${entry.src} to ZIP:`, err);
        }
    }

    // ============================================
    // 2. CREATE HTML FILE (Task K1: Use Preview HTML)
    // ============================================
    
    console.log("📄 Task K1: Creating HTML file from preview...");
    
    // K1.2: Get HTML from preview instead of rebuilding
    const previewHtml = typeof getPreviewHtml === 'function' ? getPreviewHtml() : null;
    
    if (previewHtml) {
        // Wrap in minimal HTML document structure
        const htmlDoc = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName} - Email Preview</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }
        .email-preview-content {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 40px;
        }
        /* Import key preview styles */
        .preview-logo { text-align: center; margin-bottom: 30px; }
        .preview-logo img { max-width: 200px; }
        .preview-headline { font-size: 24px; font-weight: bold; color: #351F65; margin-bottom: 20px; }
        .preview-body { font-size: 16px; line-height: 1.6; color: #333; margin-bottom: 20px; }
        .preview-cta-container { text-align: center; margin: 30px 0; }
        .preview-cta {
            display: inline-block;
            background: #6240E8;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    ${previewHtml}
</body>
</html>`;
        
        zip.file("index.html", htmlDoc);
        console.log("✅ HTML file created from preview");
    } else {
        console.error("❌ Could not get preview HTML - getPreviewHtml() unavailable");
    }

    // ============================================
    // 3. CREATE PDF FILE (Task K1: Use Preview HTML)
    // ============================================
    console.log("📄 Starting PDF generation from preview...");
    
    let pdfCreated = false;
    try {
        // K1.2: Use the preview element directly
        const previewElement = document.getElementById('preview-content');
        if (previewElement && typeof html2canvas !== 'undefined' && typeof jspdf !== 'undefined') {
            console.log("Libraries loaded, creating PDF from preview...");
            
            // Clone the element
            const cloneElement = previewElement.cloneNode(true);
            
            // Keep images but add crossOrigin attribute
            const images = cloneElement.querySelectorAll('img');
            images.forEach(img => {
                img.crossOrigin = 'anonymous';
            });
            
            console.log("Found", images.length, "images in preview");
            
            // Temporarily add to document for rendering
            cloneElement.style.position = 'absolute';
            cloneElement.style.left = '-9999px';
            cloneElement.style.width = previewElement.offsetWidth + 'px';
            document.body.appendChild(cloneElement);
            
            // Wait for rendering
            await new Promise(resolve => setTimeout(resolve, 500));
            
            console.log("Generating canvas with balanced quality...");
            const canvas = await html2canvas(cloneElement, {
                scale: 1.2,
                backgroundColor: '#ffffff',
                logging: false,
                useCORS: true,
                allowTaint: true
            });
            
            console.log("Canvas created:", canvas.width, "x", canvas.height);
            
            // Remove temporary clone
            document.body.removeChild(cloneElement);
            
            console.log("Creating single-page PDF from canvas...");
            const imgData = canvas.toDataURL('image/jpeg', 0.92);
            const { jsPDF } = jspdf;
            
            // Calculate dimensions to fit on one page
            const imgWidth = canvas.width;
            const imgHeight = canvas.height;
            const ratio = imgWidth / imgHeight;
            
            const pageWidth = 210;
            const pageHeight = 297;
            
            let pdfWidth = pageWidth;
            let pdfHeight = pageWidth / ratio;
            
            if (pdfHeight > pageHeight) {
                pdfHeight = pageHeight;
                pdfWidth = pageHeight * ratio;
            }
            
            const pdf = new jsPDF({
                orientation: pdfHeight > pdfWidth ? 'portrait' : 'landscape',
                unit: 'mm',
                format: 'a4',
                compress: true
            });
            
            const xOffset = (pageWidth - pdfWidth) / 2;
            const yOffset = (pageHeight - pdfHeight) / 2;
            
            pdf.addImage(imgData, 'JPEG', xOffset, yOffset, pdfWidth, pdfHeight);
            
            console.log("PDF object created, generating blob...");
            const pdfBlob = pdf.output('blob');
            console.log("PDF blob size:", pdfBlob.size, "bytes =", (pdfBlob.size / 1024 / 1024).toFixed(2), "MB");
            
            zip.file(projectName + "-email-preview.pdf", pdfBlob);
            console.log("PDF added to ZIP");
            pdfCreated = true;
        } else {
            console.log("PDF generation skipped - missing element or libraries");
        }
    } catch (pdfError) {
        console.error("PDF generation error:", pdfError);
        alert("Note: PDF generation encountered an error. Continuing with other files.\nError: " + pdfError.message);
    }

    // ============================================
    // 4. GENERATE ZIP AND SAVE TO INDEXEDDB
    // ============================================
    console.log("Generating ZIP file...");
    const zipBlob = await zip.generateAsync({ type: "blob" });
    console.log("ZIP blob size:", zipBlob.size, "bytes =", (zipBlob.size / 1024 / 1024).toFixed(2), "MB");

    // Convert blob to base64 for storage
    const reader = new FileReader();
    reader.onloadend = async function () {
        const base64data = reader.result;

        // Create export entry in My Designs with .zip extension
        const exportKey = 'email-export-' + Date.now();
        
        try {
            // TASK J: Export schema aligned with downloadExportFromCard
            const exportData = {
                projectName: projectName + ".zip",
                exportType: "zip",
                fileData: base64data,
                fileName: projectName + ".zip",
                sourceProject: window.currentLocalStorageKey || window.currentProjectName,
                exportDate: new Date().toISOString(),
                isExport: true
            };

            // Save to IndexedDB instead of localStorage
            await dbSave(exportKey, JSON.stringify(exportData));
            console.log("Export saved to IndexedDB");

            // Add to selected folder from Export modal
            if (selectedExportFolder && typeof addItemToFolder === 'function') {
                await addItemToFolder(selectedExportFolder, exportKey);
            }

            const successMessage = pdfCreated ? 
                `Export package saved to My Designs!\n\nContents:\n• Content Brief (.xls)\n• Email Preview (index.html matching Live Preview)\n• Email Preview PDF (includes header + logo)\n• Images folder (${allImages.length} images: ${allImages.filter(i => i.sourceType === 'uploaded').length} uploaded + ${allImages.filter(i => i.sourceType === 'static').length} static assets)` :
                `Export package saved to My Designs!\n\nContents:\n• Content Brief (.xls)\n• Email Preview (index.html)\n• Images folder (${allImages.length} images)\n\nNote: PDF generation failed`;
            
            alert(successMessage);
            closeExportModal();

            // Return to folder view
            goBackFromBuilder();
            
        } catch (storageError) {
            // If storage fails, trigger direct download
            console.error("Storage failed, downloading directly:", storageError);
            const link = document.createElement("a");
            link.href = URL.createObjectURL(zipBlob);
            link.download = projectName + ".zip";
            link.click();
            
            alert("Unable to save to My Designs.\nDownloading directly to your computer instead.");
            closeExportModal();
        }
        
        console.log("=== Export Complete (Task K) ===");
    };
    reader.readAsDataURL(zipBlob);
}

// ============================================
// TASK J: ROBUST EXPORT DOWNLOAD FUNCTION
// ============================================

/**
 * Downloads an export ZIP file from IndexedDB with support for multiple formats
 * 
 * Export Schema (current format from exportAsExcel):
 * - projectName: Display name (e.g., "my-email.zip")
 * - fileName: Download filename
 * - fileData: Base64 data URL (e.g., "data:application/zip;base64,...")
 * - exportType: "zip"
 * - sourceProject: Original design key or name
 * - exportDate: ISO timestamp
 * - isExport: true
 * 
 * Legacy formats also supported:
 * - Old Base64 with different structure
 * - Future: Firebase Storage URLs (storageUrl, downloadUrl fields)
 * 
 * @param {string} exportKey - IndexedDB key for the export document
 */
async function downloadExportFromCard(exportKey) {
    try {
        console.log("=== downloadExportFromCard called ===");
        console.log("📦 Export key:", exportKey);
        
        // Load export data from IndexedDB
        const dataStr = await dbGet(exportKey);
        if (!dataStr) {
            console.error("❌ Export not found in IndexedDB");
            alert("Export file not found. It may have been deleted.");
            return;
        }
        
        // Parse the data - handle nested structure from Firestore
        const rawData = JSON.parse(dataStr);
        const exportData = rawData.data || rawData;
        
        // Log export document schema for diagnostics
        console.log("📋 Export doc schema (keys present):", Object.keys(exportData));
        console.log("📋 Full export data:", exportData);
        
        // Validate this is actually an export
        if (!exportData.isExport) {
            console.error("❌ Document is not an export (missing isExport flag)");
            alert("This doesn't appear to be a valid export file.");
            return;
        }
        
        // ============================================
        // DETERMINE DOWNLOAD METHOD
        // ============================================
        
        let downloadMethod = null;
        let downloadUrl = null;
        let filename = exportData.fileName || exportData.projectName || 'export.zip';
        
        // Method 1: Firebase Storage URL (future support)
        if (exportData.storageUrl || exportData.downloadUrl) {
            downloadMethod = 'storageUrl';
            downloadUrl = exportData.storageUrl || exportData.downloadUrl;
            console.log("✓ Download method selected: Firebase Storage URL");
            console.log("🔗 Storage URL:", downloadUrl);
        }
        // Method 2: Legacy Base64 data
        else if (exportData.fileData) {
            downloadMethod = 'base64';
            console.log("✓ Download method selected: Base64 (legacy format)");
            console.log("📊 Base64 data length:", exportData.fileData.length, "characters");
        }
        // Method 3: No usable data
        else {
            downloadMethod = 'missing';
            console.error("❌ Download method: MISSING - No fileData, storageUrl, or downloadUrl found");
        }
        
        // ============================================
        // EXECUTE DOWNLOAD
        // ============================================
        
        if (downloadMethod === 'storageUrl') {
            // Future implementation: Direct download from Firebase Storage
            console.log("🔽 Triggering download from Firebase Storage URL...");
            const link = document.createElement("a");
            link.href = downloadUrl;
            link.download = filename;
            link.target = "_blank"; // Open in new tab if CORS issues
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            console.log("✅ Download triggered via storage URL");
            
        } else if (downloadMethod === 'base64') {
            // Legacy Base64 format - reconstruct Blob
            console.log("🔽 Converting Base64 to Blob for download...");
            
            try {
                // Extract MIME type and Base64 data
                const parts = exportData.fileData.split(',');
                const mimeString = parts[0].split(':')[1].split(';')[0];
                const byteString = atob(parts[1]);
                
                console.log("📊 MIME type:", mimeString);
                console.log("📊 Decoded byte length:", byteString.length);
                
                // Convert to Uint8Array
                const ab = new ArrayBuffer(byteString.length);
                const ia = new Uint8Array(ab);
                for (let i = 0; i < byteString.length; i++) {
                    ia[i] = byteString.charCodeAt(i);
                }
                
                // Create Blob
                const blob = new Blob([ab], { type: mimeString });
                console.log("📊 Blob size:", blob.size, "bytes =", (blob.size / 1024 / 1024).toFixed(2), "MB");
                
                // Trigger download using Object URL
                const objectUrl = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = objectUrl;
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                // Clean up object URL
                setTimeout(() => URL.revokeObjectURL(objectUrl), 100);
                
                console.log("✅ Download triggered via Base64 Blob");
                
            } catch (base64Error) {
                console.error("❌ Failed to process Base64 data:", base64Error);
                alert("Error processing export file. The file may be corrupted.");
                return;
            }
            
        } else {
            // No usable download data found
            console.error("❌ Cannot download - no valid data source");
            alert(
                "We couldn't find downloadable data for this export.\n\n" +
                "This may happen if the export is corrupted or incomplete.\n\n" +
                "Please try exporting your design again."
            );
            return;
        }
        
        console.log("=== downloadExportFromCard completed ===");
        
    } catch (err) {
        console.error("❌ ERROR in downloadExportFromCard:", err);
        console.error("Error stack:", err.stack);
        alert("Error downloading export file: " + err.message);
    }
}

// ============================================
// LEGACY FUNCTION - REDIRECTS TO NEW ONE
// ============================================

/**
 * Legacy download function - now redirects to robust implementation
 * Kept for backward compatibility
 */
async function downloadExportFile(exportKey) {
    console.log("⚠️ downloadExportFile (legacy) called, redirecting to downloadExportFromCard");
    await downloadExportFromCard(exportKey);
}

// Expose both functions globally
window.downloadExportFromCard = downloadExportFromCard;
window.downloadExportFile = downloadExportFile;
