/**
 * GSAP MODAL ANIMATIONS
 * Smooth fade + scale animations for all modals and accordions
 */

/**
 * Animate a modal opening
 * @param {HTMLElement} modal - The modal element to animate
 */
window.animateModalOpen = function(modal) {
    if (!modal || typeof gsap === 'undefined') {
        console.warn('GSAP not available or modal element missing');
        return;
    }
    
    // Set initial state
    gsap.set(modal, {
        opacity: 0,
        scale: 0.95
    });
    
    // Animate in
    gsap.to(modal, {
        opacity: 1,
        scale: 1,
        duration: 0.22,
        ease: 'power2.out'
    });
};

/**
 * Animate a modal closing
 * @param {HTMLElement} modal - The modal element to animate
 * @param {Function} onComplete - Callback to execute after animation
 */
window.animateModalClose = function(modal, onComplete) {
    if (!modal || typeof gsap === 'undefined') {
        console.warn('GSAP not available or modal element missing');
        if (typeof onComplete === 'function') {
            onComplete();
        }
        return;
    }
    
    // Animate out
    gsap.to(modal, {
        opacity: 0,
        scale: 0.95,
        duration: 0.16,
        ease: 'power2.in',
        onComplete: function() {
            if (typeof onComplete === 'function') {
                onComplete();
            }
        }
    });
};

/**
 * Animate an accordion opening
 * @param {HTMLElement} content - The accordion content element
 */
window.animateAccordionOpen = function(content) {
    if (!content || typeof gsap === 'undefined') {
        console.warn('GSAP not available or content element missing');
        return;
    }
    
    // Get the natural height
    const height = content.scrollHeight;
    
    // Animate to natural height
    gsap.to(content, {
        height: height,
        opacity: 1,
        duration: 0.4,
        ease: 'power2.inOut'
    });
};

/**
 * Animate an accordion closing
 * @param {HTMLElement} content - The accordion content element
 */
window.animateAccordionClose = function(content) {
    if (!content || typeof gsap === 'undefined') {
        console.warn('GSAP not available or content element missing');
        return;
    }
    
    // Animate to zero height
    gsap.to(content, {
        height: 0,
        opacity: 0,
        duration: 0.4,
        ease: 'power2.inOut'
    });
};

console.log('✅ GSAP animation functions loaded');
