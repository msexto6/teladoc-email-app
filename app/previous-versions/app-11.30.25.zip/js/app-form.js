// LOAD PIPELINE V2: Guard form handlers during project loads
// SPRINT F: Added isDesignLoading guards to prevent race conditions

/**
 * SPRINT: DEFAULT VALUES
 * Initialize formData from template field definitions
 * Reads `defaultValue` property from each field and populates formData
 * This replaces the hardcoded Object.assign blocks
 */
function initializeFormDataFromTemplate(templateDef) {
    if (!templateDef || !templateDef.fields) {
        console.warn("initializeFormDataFromTemplate: No template or fields provided");
        return;
    }
    
    console.log("📋 Initializing formData from template defaultValues...");
    
    templateDef.fields.forEach(field => {
        // Skip image fields - they don't have text default values
        if (field.type === 'image') return;
        
        // Check for defaultValue (preferred), value (legacy), or initialValue
        const defaultVal = field.defaultValue || field.value || field.initialValue || null;
        
        if (defaultVal) {
            window.formData[field.id] = defaultVal;
            console.log(`   ✓ ${field.id}: "${defaultVal.substring(0, 40)}${defaultVal.length > 40 ? '...' : ''}"`);
        }
    });
    
    console.log(`📋 Initialized ${Object.keys(window.formData).length} fields from template defaults`);
}

/**
 * SPRINT N2: Apply example defaults for subject, preview, and URLs
 * Applies "Example subject line", "Example preview text", and "https://example.com"
 * to empty fields in NEW designs only (not saved designs)
 * 
 * @param {Object} formData - The formData object to apply defaults to
 * @param {Array} fieldDefs - Template field definitions
 * @returns {Object} The modified formData object
 */
function applyExampleDefaults(formData, fieldDefs) {
    if (!formData) formData = {};
    
    console.log("📝 Applying example defaults for NEW design...");
    
    if (fieldDefs && Array.isArray(fieldDefs)) {
        fieldDefs.forEach((field) => {
            const key = field.id || field.name;
            if (!key || field.type === 'image') return;
            
            const current = (formData[key] || '').toString().trim();
            
            // Only apply defaults if field is currently empty
            if (!current) {
                const lower = key.toLowerCase();
                
                // Check for subject line field
                if (lower.includes('subject')) {
                    formData[key] = 'Example subject line';
                    console.log(`   ✓ ${key}: "Example subject line"`);
                }
                // Check for preview text field
                else if (lower.includes('preview')) {
                    formData[key] = 'Example preview text';
                    console.log(`   ✓ ${key}: "Example preview text"`);
                }
                // Check for URL fields
                else if (lower.endsWith('url') || lower.endsWith('-url') || lower.includes('link')) {
                    formData[key] = 'https://example.com';
                    console.log(`   ✓ ${key}: "https://example.com"`);
                }
            }
        });
    }
    
    console.log(`📝 Example defaults applied`);
    return formData;
}

function handleTemplateChange(e) {
    // SPRINT F: Guard against template changes during design load
    if (typeof window.isDesignLoading === 'function' && window.isDesignLoading()) {
        console.log("⏳ Ignoring template change during design load");
        return;
    }
    
    // LOAD PIPELINE V2: Guard against template changes during project load
    if (window.isLoadingProject) {
        console.log("⏳ Ignoring template change during project load");
        return;
    }

    const val = e.target.value;
    const creativeSection = document.getElementById("creative-direction-section");
    const actionButtons = document.getElementById("action-buttons");
    
    if(!val) {
        currentTemplate = null;
        currentTemplateKey = null;
        document.getElementById("email-form").innerHTML = "";
        actionButtons.classList.remove("active");
        creativeSection.classList.remove("active");
        updatePreview();
        return;
    }
    
    currentTemplate = templates[val];
    currentTemplateKey = val;
    
    // Update title based on whether this is a fresh template or saved design
    const builderTitle = document.getElementById('builder-template-title');
    const projectInfoDisplay = document.getElementById('project-info-display');
    const projectNameDisplay = document.getElementById('project-name-display');
    
    if (isLoadingSavedDesign) {
        // SAVED DESIGN PATH: Show project name (big) with template name (small) below
        if (builderTitle) {
            builderTitle.textContent = savedDesignName;
        }
        if (projectInfoDisplay && projectNameDisplay) {
            projectNameDisplay.textContent = savedDesignTemplateName;
            projectInfoDisplay.style.display = 'flex';
        }
    } else {
        // FRESH TEMPLATE PATH: Show template name (big) with no subtitle
        if (builderTitle) {
            builderTitle.textContent = currentTemplate.name;
        }
        if (projectInfoDisplay) {
            projectInfoDisplay.style.display = 'none';
        }
    }
    
    // Reset global formData safely
    Object.keys(window.formData).forEach(key => delete window.formData[key]);
    
    // SPRINT: DEFAULT VALUES - Initialize formData from template defaultValues
    // This replaces the hardcoded Object.assign blocks
    initializeFormDataFromTemplate(currentTemplate);
    
    // Legacy hardcoded defaults for webinar templates that have extra fields
    // not defined in templates.js (e.g., eyebrow, signature fields, speakers)
    // These should eventually be moved to templates.js as defaultValue properties
    if(val === "webinar-invite") {
        Object.assign(window.formData, {
            "eyebrow": "Webinar",
            "datetime": "June 10, 2025 | 11:30-12:30 PM ET",
            "signature-name": "Kristen Moody",
            "signature-title": "Chief Client Officer",
            "signature-company": "Teladoc Health",
            "speaker-1": "Kristen Moody, Chief Client Officer, Teladoc Health",
            "speaker-2": "Eddie Swafford, Senior Vice President, Operations, Teladoc Health",
            "speaker-3": "Brian Serfass, Senior Vice President, Consumer Marketing, Teladoc Health"
        });
    } else if(val === "webinar-reg-confirmation") {
        Object.assign(window.formData, {
            "date": "September 9, 2025",
            "time": "2:30 PM ET",
            "link": "Access the webinar",
            "contact-info": "If you have questions, please reach out."
        });
    } else if(val === "webinar-reminder") {
        // Rich text body copy with formatted content
        window.formData["body-copy"] = `<div>Thank you for registering for the webinar.</div><div><br></div><div>The event will start promptly at <strong>11:30AM ET</strong>.</div><div><br></div><div>Here is your access link for the webinar:</div><div><a href="https://www.example.com" style="color:#6240E8;">Access the webinar</a></div><div><br></div><div>If you are unable to join us live, we'll share a recording of the webinar so you can watch it at your convenience.</div><div><br></div><div>Thank you,</div><div><br></div><div><strong>The Teladoc Health Team</strong></div>`;
    } else if(val === "webinar-post-attendee") {
        // Rich text with HTML formatting
        Object.assign(window.formData, {
            "body-copy": "<p>Thank you for joining us at the September Client Connections webinar. I hope you found the discussion valuable and walked away with actionable insights to support your population.</p><p>If you'd like to revisit any part of the conversation—or share it with colleagues—the full recording is <a href='#' style='color:#6240E8;'>now available to watch on demand</a>.</p><p>Thank you again for your continued partnership.</p>",
            "highlighted-title": "Want more insights like this?",
            "highlighted-copy": "<p>Be sure to join us for our next <em>Client Connections</em> webinar on <a href='#' style='color:#6240E8;'>Tuesday, November 5 at 11:30 AM ET</a>. You'll hear directly from clinical and strategy leaders as they unveil new advancements and share how Teladoc Health is orchestrating more connected, personalized support across our solutions.</p>",
            "cta-2": "Register now"
        });
    }
    
    // SPRINT N3b: Apply example defaults unconditionally (safe, empty-only)
    // applyExampleDefaults only fills EMPTY fields, so it's safe for both new and existing designs
    applyExampleDefaults(window.formData, currentTemplate.fields);
    
    uploadedImages = {};
    
    console.log("Initialized default formData for template:", val, window.formData);
    
    creativeSection.classList.add("active");
    document.getElementById("creative-direction-top").value = "[Choose one]";
    
    actionButtons.classList.add("active");
    
    generateForm();
    populateFormFields();
    updatePreview();
    
    console.log("📊 After template change, formData initialized with:", Object.keys(formData).length, "fields");
}

// ============================================
// FORM GENERATION
// ============================================

// PHASE 2 TASK B2: Robust generateForm with comprehensive error handling
// PHASE 3 TASK D: Now initializes form fields with default values from template definitions
function generateForm(templateKey, templateDefinition) {
    console.group("🧩 generateForm");

    // 1. Resolve the template key
    let key = templateKey || window.currentTemplateKey || null;

    // If no key was passed, try to infer it from the current template
    if (!key && window.currentTemplate && window.currentTemplate.id) {
        key = window.currentTemplate.id;
    }

    // 2. Resolve the template definition from the various sources
    let definition =
        templateDefinition ||
        window.currentTemplate ||
        (window.templates && key ? window.templates[key] : null) ||
        (window.templateDefinitions && key ? window.templateDefinitions[key] : null) ||
        null;

    if (!key) {
        console.error("generateForm: no templateKey provided or inferred.", {
            templateKey,
            currentTemplateKey: window.currentTemplateKey
        });
        console.groupEnd();
        return;
    }

    if (!definition) {
        console.error("generateForm: no template definition found for key:", key, {
            templateKey,
            definitionPassedIn: !!templateDefinition,
            hasWindowTemplates: !!window.templates,
            hasWindowTemplateDefinitions: !!window.templateDefinitions,
            availableKeys: window.templates ? Object.keys(window.templates) : []
        });
        console.groupEnd();
        return;
    }

    if (!definition.fields || !Array.isArray(definition.fields)) {
        console.error("generateForm: template definition has no valid 'fields' array.", {
            key,
            definition
        });
        console.groupEnd();
        return;
    }

    // 3. Persist resolved state globally so other code can rely on it
    window.currentTemplateKey = key;
    window.currentTemplate = definition;

    console.log("✅ generateForm: using template", {
        key,
        name: definition.name,
        fieldCount: definition.fields.length
    });

    // 4. Build the form using existing logic
    const formContainer = document.getElementById("email-form");
    if (!formContainer) {
        console.error("generateForm: form container '#email-form' not found.");
        console.groupEnd();
        return;
    }

    // Clear previous fields
    formContainer.innerHTML = "";

    // Build each field from the definition
    definition.fields.forEach((fieldDef) => {
        // Skip hidden fields
        if (!fieldDef.hidden) {
            formContainer.appendChild(createFormField(fieldDef));
        }
    });

    console.groupEnd();
}


function createFormField(field) {
    const div = document.createElement("div");
    div.className = "form-field";
    
    const label = document.createElement("label");
    label.textContent = field.label;
    div.appendChild(label);
    
    if(field.type === "image") {
        div.appendChild(createImageUpload(field));
    } else if(field.type === "textarea") {
        div.appendChild(createTextarea(field));
    } else {
        div.appendChild(createTextInput(field));
    }
    
    return div;
}

// ============================================
// IMAGE UPLOAD HANDLING
// ============================================

// PHASE 3 TASK D: Modified to apply default values from template definitions
// SPRINT: DEFAULT VALUES - Now reads defaultValue property from field definitions
// SPRINT F: Added isDesignLoading guard to input listeners
function createTextInput(field) {
    const div = document.createElement("div");
    
    // Check if this field should have rich text (link field)
    if(field.id === "link") {
        const toolbar = document.createElement("div");
        toolbar.className = "formatting-toolbar";
        toolbar.innerHTML = `
            <button type="button" class="format-btn" data-format="bold" title="Bold">
                <strong>B</strong>
            </button>
            <button type="button" class="format-btn" data-format="italic" title="Italic">
                <em>I</em>
            </button>
            <button type="button" class="format-btn" data-format="underline" title="Underline">
                <u>U</u>
            </button>
            <button type="button" class="format-btn" data-format="link" title="Insert Link">
                🔗
            </button>
        `;
        div.appendChild(toolbar);
        
        const editor = document.createElement("div");
        editor.id = field.id;
        editor.className = "form-input rich-text-editor";
        editor.contentEditable = "true";
        editor.setAttribute("data-placeholder", field.placeholder || "");
        editor.style.minHeight = "60px";
        
        // SPRINT: DEFAULT VALUES - Priority: formData > defaultValue > value > initialValue
        // formData may already have value from initializeFormDataFromTemplate()
        const storedValue = window.formData?.[field.id];
        const templateDefault = field.defaultValue || field.value || field.initialValue || null;
        const initialValue = (storedValue != null && storedValue !== '') ? storedValue : (templateDefault || '');
        
        if (initialValue) {
            if (typeof window.setEditorHTML === 'function') {
                window.setEditorHTML(editor, initialValue);
            } else {
                editor.innerHTML = initialValue;
            }
            // Ensure formData is in sync
            window.formData[field.id] = initialValue;
        }
        
        div.appendChild(editor);
        
        toolbar.addEventListener("click", (e) => {
            const btn = e.target.closest(".format-btn");
            if(!btn) return;
            
            const format = btn.dataset.format;
            applyRichFormat(editor, format);
        });
        
        editor.addEventListener("input", () => {
            // SPRINT F: Guard during design load
            if (typeof window.isDesignLoading === 'function' && window.isDesignLoading()) {
                return;
            }
            
            // LOAD PIPELINE V2: Guard during project load
            if (window.isLoadingProject) {
                return;
            }
            
            // SPRINT A: Clear field error on input
            clearFieldError(field.id);
            
            console.log(`📝 Rich text field "${field.id}" updated`);
            formData[field.id] = getEditorHTML(editor);
            console.log(`   formData["${field.id}"] = "${formData[field.id]?.substring(0, 30)}..."`);
            if(field.maxChars) {
                updateCharacterCounterFromEditor(editor, field.maxChars);
            }
            updatePreview();
        });
        
        if(field.maxChars) {
            const counter = document.createElement("div");
            counter.className = "char-counter";
            counter.innerHTML = `
                <span class="char-count">0 / ${field.maxChars}</span>
                <div class="char-progress-bar">
                    <div class="char-progress-fill safe" style="width:0%"></div>
                </div>
            `;
            div.appendChild(counter);
            
            // Update counter immediately if there's initial value
            if (initialValue) {
                setTimeout(() => updateCharacterCounterFromEditor(editor, field.maxChars), 50);
            }
        }
    } else {
        // Regular text input
        const input = document.createElement("input");
        input.type = "text";
        input.id = field.id;
        input.className = "form-input";
        input.placeholder = field.placeholder || "";
        input.setAttribute("data-field-id", field.id); // SPRINT A: Add data attribute for error mapping
        
        // SPRINT: DEFAULT VALUES - Priority: formData > defaultValue > value > initialValue
        // formData may already have value from initializeFormDataFromTemplate()
        const storedValue = window.formData?.[field.id];
        const templateDefault = field.defaultValue || field.value || field.initialValue || null;
        const initialValue = (storedValue != null && storedValue !== '') ? storedValue : (templateDefault || '');
        
        if (initialValue) {
            input.value = initialValue;
            // Ensure formData is in sync
            window.formData[field.id] = initialValue;
        }
        
        div.appendChild(input);

        // CRITICAL FIX: Always add input listener, regardless of maxChars
        input.addEventListener("input", e => {
            // SPRINT F: Guard during design load
            if (typeof window.isDesignLoading === 'function' && window.isDesignLoading()) {
                return;
            }
            
            // LOAD PIPELINE V2: Guard during project load
            if (window.isLoadingProject) {
                return;
            }
            
            // SPRINT A: Clear field error on input
            clearFieldError(field.id);
            
            console.log(`📝 Text field "${field.id}" updated to: "${e.target.value}"`);
            formData[field.id] = e.target.value;
            console.log(`   Current formData keys: [${Object.keys(formData).join(', ')}]`);
            
            // Only update character counter if field has maxChars
            if(field.maxChars) {
                updateCharacterCounter(input, field.maxChars);
            }
            updatePreview();
        });
        
        // Add character counter UI only if maxChars is specified
        if(field.maxChars) {
            const counter = document.createElement("div");
            counter.className = "char-counter";
            counter.innerHTML = `
                <span class="char-count">0 / ${field.maxChars}</span>
                <div class="char-progress-bar">
                    <div class="char-progress-fill safe" style="width:0%"></div>
                </div>
            `;
            div.appendChild(counter);
            
            // Update counter immediately if there's initial value
            if (initialValue) {
                setTimeout(() => updateCharacterCounter(input, field.maxChars), 50);
            }
        }
    }
    
    return div;
}

// PHASE 3 TASK D: Modified to apply default values from template definitions
// SPRINT: DEFAULT VALUES - Now reads defaultValue property from field definitions
// SPRINT F: Added isDesignLoading guard to input listeners
function createTextarea(field) {
    const div = document.createElement("div");
    
    // Add formatting toolbar for body-copy, highlight-body, highlight-copy, resources-section, and news-section fields
    if(field.id === "body-copy" || field.id === "highlight-body" || field.id === "highlight-copy" || field.id === "resources-section" || field.id === "news-section") {
        const toolbar = document.createElement("div");
        toolbar.className = "formatting-toolbar";
        toolbar.innerHTML = `
            <button type="button" class="format-btn" data-format="bold" title="Bold">
                <strong>B</strong>
            </button>
            <button type="button" class="format-btn" data-format="italic" title="Italic">
                <em>I</em>
            </button>
            <button type="button" class="format-btn" data-format="underline" title="Underline">
                <u>U</u>
            </button>
            <button type="button" class="format-btn" data-format="link" title="Insert Link">
                🔗
            </button>
            <button type="button" class="format-btn" data-format="bulletList" title="Bullet List">
                ≡
            </button>
        `;
        div.appendChild(toolbar);
        
        // Create contenteditable div instead of textarea for rich text
        const editor = document.createElement("div");
        editor.id = field.id;
        editor.className = "form-input form-textarea rich-text-editor";
        editor.contentEditable = "true";
        editor.setAttribute("data-placeholder", field.placeholder || "");
        editor.setAttribute("data-field-id", field.id); // SPRINT A: Add data attribute for error mapping
        
        // SPRINT: DEFAULT VALUES - Priority: formData > defaultValue > value > initialValue
        // formData may already have value from initializeFormDataFromTemplate()
        const storedValue = window.formData?.[field.id];
        const templateDefault = field.defaultValue || field.value || field.initialValue || null;
        const initialValue = (storedValue != null && storedValue !== '') ? storedValue : (templateDefault || '');
        
        if (initialValue) {
            if (typeof window.setEditorHTML === 'function') {
                window.setEditorHTML(editor, initialValue);
            } else {
                editor.innerHTML = initialValue;
            }
            // Ensure formData is in sync
            window.formData[field.id] = initialValue;
        }
        
        div.appendChild(editor);
        
        // Add event listeners for formatting buttons
        toolbar.addEventListener("click", (e) => {
            const btn = e.target.closest(".format-btn");
            if(!btn) return;
            
            const format = btn.dataset.format;
            applyRichFormat(editor, format);
        });
        
        // Handle input events
        editor.addEventListener("input", () => {
            // SPRINT F: Guard during design load
            if (typeof window.isDesignLoading === 'function' && window.isDesignLoading()) {
                return;
            }
            
            // LOAD PIPELINE V2: Guard during project load
            if (window.isLoadingProject) {
                return;
            }
            
            // SPRINT A: Clear field error on input
            clearFieldError(field.id);
            
            console.log(`📝 Textarea rich field "${field.id}" updated`);
            formData[field.id] = getEditorHTML(editor);
            console.log(`   formData["${field.id}"] = "${formData[field.id]?.substring(0, 30)}..."`);
            if(field.maxChars) {
                updateCharacterCounterFromEditor(editor, field.maxChars);
            }
            updatePreview();
        });
        
        if(field.maxChars) {
            const counter = document.createElement("div");
            counter.className = "char-counter";
            counter.innerHTML = `
                <span class="char-count">0 / ${field.maxChars}</span>
                <div class="char-progress-bar">
                    <div class="char-progress-fill safe" style="width:0%"></div>
                </div>
            `;
            div.appendChild(counter);
            
            // Update counter immediately if there's initial value
            if (initialValue) {
                setTimeout(() => updateCharacterCounterFromEditor(editor, field.maxChars), 50);
            }
        }
        
    } else {
        // Regular textarea for non-body-copy fields
        const textarea = document.createElement("textarea");
        textarea.id = field.id;
        textarea.className = "form-input form-textarea";
        textarea.placeholder = field.placeholder || "";
        textarea.setAttribute("data-field-id", field.id); // SPRINT A: Add data attribute for error mapping
        
        // SPRINT: DEFAULT VALUES - Priority: formData > defaultValue > value > initialValue
        // formData may already have value from initializeFormDataFromTemplate()
        const storedValue = window.formData?.[field.id];
        const templateDefault = field.defaultValue || field.value || field.initialValue || null;
        const initialValue = (storedValue != null && storedValue !== '') ? storedValue : (templateDefault || '');
        
        if (initialValue) {
            textarea.value = initialValue;
            // Ensure formData is in sync
            window.formData[field.id] = initialValue;
        }
        
        div.appendChild(textarea);
        
        textarea.addEventListener("input", e => {
            // SPRINT F: Guard during design load
            if (typeof window.isDesignLoading === 'function' && window.isDesignLoading()) {
                return;
            }
            
            // LOAD PIPELINE V2: Guard during project load
            if (window.isLoadingProject) {
                return;
            }
            
            // SPRINT A: Clear field error on input
            clearFieldError(field.id);
            
            console.log(`📝 Textarea field "${field.id}" updated`);
            formData[field.id] = e.target.value;
            console.log(`   formData["${field.id}"] = "${formData[field.id]?.substring(0, 30)}..."`);
            if(field.maxChars) {
                updateCharacterCounter(textarea, field.maxChars);
            }
            updatePreview();
        });
        
        if(field.maxChars) {
            const counter = document.createElement("div");
            counter.className = "char-counter";
            counter.innerHTML = `
                <span class="char-count">0 / ${field.maxChars}</span>
                <div class="char-progress-bar">
                    <div class="char-progress-fill safe" style="width:0%"></div>
                </div>
            `;
            div.appendChild(counter);
            
            // Update counter immediately if there's initial value
            if (initialValue) {
                setTimeout(() => updateCharacterCounter(textarea, field.maxChars), 50);
            }
        }
    }
    
    return div;
}

// ============================================
// RICH TEXT EDITING
// ============================================


function updateCharacterCounter(input, maxChars) {
    const counter = input.parentElement.querySelector(".char-counter");
    const progressFill = input.parentElement.querySelector(".char-progress-fill");
    
    if(counter && progressFill) {
        const len = input.value.length;
        const countSpan = counter.querySelector(".char-count");
        countSpan.textContent = len + " / " + maxChars;
        
        const percentage = Math.min((len/maxChars)*100, 100);
        progressFill.style.width = percentage + "%";
        
        progressFill.classList.remove("safe", "warning", "danger");
        countSpan.classList.remove("over-limit");
        
        if(len > maxChars) {
            progressFill.classList.add("danger");
            countSpan.classList.add("over-limit");
        } else if(len > maxChars * 0.8) {
            progressFill.classList.add("warning");
        } else {
            progressFill.classList.add("safe");
        }
    }
}

// ============================================
// FORM POPULATION
// ============================================


function updateCharacterCounterFromEditor(editor, maxChars) {
    const counter = editor.parentElement.querySelector(".char-counter");
    const progressFill = editor.parentElement.querySelector(".char-progress-fill");
    
    if(counter && progressFill) {
        const len = editor.textContent.length;
        const countSpan = counter.querySelector(".char-count");
        countSpan.textContent = len + " / " + maxChars;
        
        const percentage = Math.min((len/maxChars)*100, 100);
        progressFill.style.width = percentage + "%";
        
        progressFill.classList.remove("safe", "warning", "danger");
        countSpan.classList.remove("over-limit");
        
        if(len > maxChars) {
            progressFill.classList.add("danger");
            countSpan.classList.add("over-limit");
        } else if(len > maxChars * 0.8) {
            progressFill.classList.add("warning");
        } else {
            progressFill.classList.add("safe");
        }
    }
}

// ============================================
// CHARACTER COUNTER
// ============================================


function populateFormFields() {
    console.log("=== populateFormFields called ===");
    console.log("currentTemplate:", currentTemplate);
    console.log("formData being populated:", formData);
    console.log("Number of fields in formData:", Object.keys(formData).length);
    
    currentTemplate.fields.forEach(field => {
        if(formData[field.id]) {
            console.log(`Populating field ${field.id} with:`, formData[field.id]?.substring(0, 50));
            const input = document.getElementById(field.id);
            if(input) {
                if(input.contentEditable === "true") {
                    // Rich text editor
                    setEditorHTML(input, formData[field.id]);
                    // Increased timeout to allow DOM to fully update
                    setTimeout(() => {
                        if(field.maxChars) {
                            updateCharacterCounterFromEditor(input, field.maxChars);
                        }
                    }, 100);
                } else {
                    // Regular input/textarea
                    input.value = formData[field.id];
                    // Increased timeout to allow DOM to fully update
                    setTimeout(() => {
                        if(field.maxChars) {
                            updateCharacterCounter(input, field.maxChars);
                        }
                    }, 100);
                }
            } else {
                console.log(`Warning: Field element ${field.id} not found in DOM`);
            }
        }
        
        if(uploadedImages[field.id]) {
            const zone = document.getElementById(field.id + "-zone");
            if(zone) {
                zone.innerHTML = `
                    <div class="image-preview-container">
                        <img src="${uploadedImages[field.id]}" class="image-preview">
                        <button type="button" class="image-remove-btn" onclick="removeImage('${field.id}')">&times;</button>
                    </div>
                `;
            }
        }
    });
    
    console.log("=== populateFormFields completed ===");
}

// ============================================
// VIEW SWITCHING
// ============================================


function parseLinks(text) {
    if(!text) return '';
    return text;
}


function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// PREVIEW UPDATE (ROUTER)
// ============================================

// Add debug logging to save function
window.debugSave = function() {
    console.log("🔍 DEBUG SAVE - Current state:");
    console.log("  formData:", formData);
    console.log("  formData keys:", Object.keys(formData));
    console.log("  formData entries:", Object.entries(formData));
    console.log("  currentTemplate:", currentTemplate);
    console.log("  currentTemplateKey:", currentTemplateKey);
    
    // Also log field values directly from DOM
    console.log("🔍 DOM field values:");
    if (currentTemplate && currentTemplate.fields) {
        currentTemplate.fields.forEach(field => {
            const element = document.getElementById(field.id);
            if (element) {
                const value = element.contentEditable === "true" ? 
                    element.innerHTML : 
                    element.value;
                console.log(`  ${field.id}: "${value?.substring(0, 50)}..."`);
            }
        });
    }
};

// ============================================
// SPRINT A & SPRINT H: VALIDATION SYSTEM
// ============================================

/**
 * SPRINT H: Updated validation logic - Soft character limits
 * - Required + empty = ERROR (blocks export/save)
 * - Over maxChars = WARNING only (red counter, no block)
 * 
 * @returns {Object} Validation result with isValid boolean, errors array, and warnings array
 */
function validateCurrentDesign() {
    const template = window.currentTemplate;
    const data = window.formData || {};

    const result = {
        isValid: true,
        errors: [],
        warnings: []
    };

    // If no template or no validation block, return valid
    if (!template || !template.validation) {
        console.log("✅ Validation: No validation rules for this template");
        return result;
    }

    const v = template.validation;

    // SPRINT H: Check required fields (BLOCKING errors)
    (v.requiredFields || []).forEach(fieldId => {
        const value = (data[fieldId] || "").toString().trim();
        
        // For image fields, check uploadedImages object
        if (fieldId.includes('image') || fieldId === 'hero-image') {
            if (!window.uploadedImages || !window.uploadedImages[fieldId]) {
                result.isValid = false;
                result.errors.push({
                    fieldId,
                    message: "This field is required."
                });
            }
        } else {
            // For text fields, check formData - only block if truly empty
            if (!value) {
                result.isValid = false;
                result.errors.push({
                    fieldId,
                    message: "This field is required."
                });
            }
        }
    });

    // Check minimum character lengths if specified (BLOCKING errors)
    if (v.minChars) {
        Object.keys(v.minChars).forEach(fieldId => {
            const value = (data[fieldId] || "").toString();
            const minLength = v.minChars[fieldId];
            
            // Count text content only (strip HTML)
            const textContent = value.replace(/<[^>]*>/g, '');
            
            if (textContent.length > 0 && textContent.length < minLength) {
                result.isValid = false;
                result.errors.push({
                    fieldId,
                    message: `This field must be at least ${minLength} characters.`
                });
            }
        });
    }

    // SPRINT H: Check maximum character lengths (SOFT warnings - do NOT block)
    if (v.maxChars) {
        Object.keys(v.maxChars).forEach(fieldId => {
            const value = (data[fieldId] || "").toString();
            const maxLength = v.maxChars[fieldId];
            
            // Count text content only (strip HTML)
            const textContent = value.replace(/<[^>]*>/g, '');
            
            if (textContent.length > maxLength) {
                // SPRINT H: Add to warnings array, NOT errors
                // This keeps the red counter but does NOT block export/save
                result.warnings.push({
                    fieldId,
                    message: `Over recommended length (${maxLength} characters).`,
                    isOverLimit: true
                });
            }
        });
    }

    console.log("🔍 Validation result:", result);
    return result;
}

/**
 * SPRINT A TASK A3: Set error state on a specific field
 * @param {string} fieldId - The field ID to mark as error
 * @param {string} message - Error message to display
 */
function setFieldError(fieldId, message) {
    console.log(`⚠️ Setting field error for ${fieldId}:`, message);
    
    // Try to find the field element by ID
    let el = document.getElementById(fieldId);
    
    // For image fields, find the upload zone
    if (!el || el.type === 'file') {
        el = document.getElementById(fieldId + '-zone');
    }
    
    if (!el) {
        console.warn(`Cannot find element for field ${fieldId}`);
        return;
    }

    // Add error class to the element
    el.classList.add("field-error");
    
    // Find or create error message container
    let container = el.parentElement;
    if (!container) {
        console.warn(`No parent element for field ${fieldId}`);
        return;
    }
    
    // Remove existing error message if present
    let existingMsg = container.querySelector(".field-error-message");
    if (existingMsg) {
        existingMsg.remove();
    }
    
    // Create new error message
    const msg = document.createElement("div");
    msg.className = "field-error-message";
    msg.textContent = message;
    container.appendChild(msg);
}

/**
 * SPRINT A TASK A3: Clear all field error states
 */
function clearFieldErrors() {
    console.log("🧹 Clearing all field errors");
    
    // Remove error class from all elements
    document.querySelectorAll(".field-error").forEach(el => {
        el.classList.remove("field-error");
    });
    
    // Remove all error messages
    document.querySelectorAll(".field-error-message").forEach(el => {
        el.remove();
    });
}

/**
 * SPRINT A TASK A3: Clear error state for a specific field
 * Called when user updates a field that had an error
 * @param {string} fieldId - The field ID to clear error from
 */
function clearFieldError(fieldId) {
    let el = document.getElementById(fieldId);
    
    // For image fields, find the upload zone
    if (!el || el.type === 'file') {
        el = document.getElementById(fieldId + '-zone');
    }
    
    if (!el) return;

    el.classList.remove("field-error");
    
    const container = el.parentElement;
    if (container) {
        const msg = container.querySelector(".field-error-message");
        if (msg) {
            msg.remove();
        }
    }
}

// Make validation functions available globally
window.validateCurrentDesign = validateCurrentDesign;
window.setFieldError = setFieldError;
window.clearFieldErrors = clearFieldErrors;
window.clearFieldError = clearFieldError;

// Make initializeFormDataFromTemplate and applyExampleDefaults available globally
window.initializeFormDataFromTemplate = initializeFormDataFromTemplate;
window.applyExampleDefaults = applyExampleDefaults;
