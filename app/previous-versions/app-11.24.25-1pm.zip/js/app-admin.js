// Admin Panel Module for Email Briefing App
// Provides hidden admin access to export history and system logs
// UPDATED: Phase 3 Polish - "Open design" now loads designs into builder

// ============================================
// ADMIN PANEL CONTROLS
// ============================================

function openAdminPanel() {
    const panel = document.getElementById("admin-panel");
    if (!panel) return;
    
    panel.classList.remove("hidden");
    loadExportHistory();
}

function closeAdminPanel() {
    const panel = document.getElementById("admin-panel");
    if (!panel) return;
    
    panel.classList.add("hidden");
}

// ============================================
// LOAD EXPORT HISTORY FROM FIREBASE
// ============================================

async function loadExportHistory() {
    const body = document.querySelector(".admin-panel__body");
    if (!body) return;

    body.innerHTML = "<p style='text-align:center;padding:40px;color:#9B8FC7;'>Loading export history...</p>";

    try {
        // Get date range (last 7 days)
        const today = new Date();
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(today.getDate() - 7);

        // Fetch export logs from Firebase
        const logs = await EmailBriefingDB.getExportLogs({
            startDate: sevenDaysAgo,
            endDate: today
        });

        // Render table
        body.innerHTML = renderExportHistoryTable(logs);
        
    } catch (error) {
        console.error("Failed to load export history", error);
        body.innerHTML = "<p style='text-align:center;padding:40px;color:#FF4757;'>Failed to load export history.</p>";
    }
}

// ============================================
// RENDER EXPORT HISTORY TABLE
// ============================================

function renderExportHistoryTable(logs) {
    if (!logs || logs.length === 0) {
        return "<p style='text-align:center;padding:40px;color:#9B8FC7;'>No exports found in the last 7 days.</p>";
    }

    const rows = logs.map(log => {
        const date = new Date(log.createdAt || log.timestamp);
        const dateStr = date.toLocaleString();
        const sizeKb = log.sizeBytes ? Math.round(log.sizeBytes / 1024) : "—";
        const folder = (log.folderPath || []).join(" / ") || "—";
        const userName = log.userName || "Unknown";
        const designName = log.designName || "Untitled";
        const templateKey = log.templateKey || "—";
        const designId = log.designId || log.storageKey || "";

        return `
            <tr data-design-id="${designId}">
                <td>${dateStr}</td>
                <td>${userName}</td>
                <td>${designName}</td>
                <td>${templateKey}</td>
                <td>${folder}</td>
                <td>${sizeKb} KB</td>
                <td><button class="admin-open-design-btn">Open design</button></td>
            </tr>
        `;
    }).join("");

    return `
        <div class="admin-filters">
            <p>Showing ${logs.length} exports from the last 7 days.</p>
        </div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>User</th>
                    <th>Design</th>
                    <th>Template</th>
                    <th>Folder</th>
                    <th>Size</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}

// ============================================
// OPEN DESIGN FROM ADMIN PANEL
// PHASE 3 POLISH: Now actually loads the design
// ============================================

async function openDesignFromAdmin(designId) {
    console.log("[Admin] Open design for key:", designId);
    
    if (!designId) {
        console.error("[Admin] No design ID provided");
        return;
    }
    
    // Close admin panel
    closeAdminPanel();
    
    // Navigate to My Designs screen first
    // (This ensures proper screen state before loading)
    showScreen('my-designs');
    
    // Small delay to allow screen transition
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Delegate to the existing Load Pipeline v2 loader
    console.log("[Admin] Delegating to loadDesignFromCard");
    
    // Check if loadDesignFromCard exists (it should from app-save-load.js)
    if (typeof loadDesignFromCard === 'function') {
        try {
            await loadDesignFromCard(designId);
            console.log("[Admin] ✓ Design loaded successfully");
        } catch (error) {
            console.error("[Admin] ✗ Error loading design:", error);
            showModal("Error Loading Design", "Could not load this design. It may have been deleted or corrupted.");
        }
    } else {
        console.error("[Admin] loadDesignFromCard function not found");
        showModal("Error", "Design loading function not available. Please refresh the page.");
    }
}

// ============================================
// EVENT LISTENERS
// ============================================

// Close button
document.addEventListener('DOMContentLoaded', () => {
    const closeBtn = document.getElementById("admin-panel-close");
    if (closeBtn) {
        closeBtn.addEventListener("click", closeAdminPanel);
    }
    
    // Click backdrop to close
    const backdrop = document.querySelector(".admin-panel__backdrop");
    if (backdrop) {
        backdrop.addEventListener("click", closeAdminPanel);
    }
});

// Delegated click handler for "Open design" buttons
document.addEventListener("click", (event) => {
    const btn = event.target.closest(".admin-open-design-btn");
    if (!btn) return;

    const row = btn.closest("tr");
    const designId = row?.dataset.designId;
    if (!designId) {
        console.warn("[Admin] No design ID found on row");
        return;
    }

    openDesignFromAdmin(designId);
});

// Admin hotspot click handlers (both subnav ribbons)
document.addEventListener('DOMContentLoaded', () => {
    const hotspot1 = document.getElementById("admin-access-hotspot");
    const hotspot2 = document.getElementById("admin-access-hotspot-mydesigns");
    
    if (hotspot1) {
        hotspot1.addEventListener("click", (event) => {
            // Optional: require Shift+click for extra safety
            // if (!event.shiftKey) return;
            openAdminPanel();
        });
    }
    
    if (hotspot2) {
        hotspot2.addEventListener("click", (event) => {
            // Optional: require Shift+click for extra safety
            // if (!event.shiftKey) return;
            openAdminPanel();
        });
    }
});

console.log('✓ Admin panel module loaded (Phase 3 Polish)');
