/**
 * UI ANIMATIONS - GSAP Enhancement Layer
 * Provides smooth, consistent animations for accordions, notifications, and modals
 * Non-breaking: Falls back gracefully if GSAP fails to load
 */

// ============================================
// ACCORDION ANIMATIONS
// ============================================

/**
 * Animate accordion section opening with GSAP
 * Falls back to instant display if GSAP unavailable
 * UPDATED: Slower timing (0.5s) with smoother easing
 */
function animateAccordionOpen(bodyEl) {
    if (!bodyEl) return;

    // Fallback if GSAP isn't available
    if (typeof gsap === "undefined") {
        bodyEl.style.display = "block";
        bodyEl.style.opacity = "1";
        return;
    }

    gsap.killTweensOf(bodyEl);

    // Prepare element
    bodyEl.style.display = "block";
    bodyEl.style.overflow = "hidden";

    const targetHeight = bodyEl.scrollHeight;

    gsap.fromTo(
        bodyEl,
        { height: 0, opacity: 0 },
        {
            height: targetHeight,
            opacity: 1,
            duration: 0.5,
            ease: "power2.inOut",
            onComplete: () => {
                // Let it size naturally afterwards
                bodyEl.style.height = "auto";
                bodyEl.style.overflow = "visible";
            }
        }
    );
}

/**
 * Animate accordion section closing with GSAP
 * Falls back to instant hide if GSAP unavailable
 * UPDATED: Slower timing (0.4s) with smoother easing
 */
function animateAccordionClose(bodyEl) {
    if (!bodyEl) return;

    if (typeof gsap === "undefined") {
        bodyEl.style.display = "none";
        return;
    }

    gsap.killTweensOf(bodyEl);

    const currentHeight = bodyEl.offsetHeight || bodyEl.scrollHeight;
    bodyEl.style.overflow = "hidden";

    gsap.fromTo(
        bodyEl,
        { height: currentHeight, opacity: 1 },
        {
            height: 0,
            opacity: 0,
            duration: 0.4,
            ease: "power2.inOut",
            onComplete: () => {
                bodyEl.style.display = "none";
                bodyEl.style.height = "";
            }
        }
    );
}

// ============================================
// NOTIFICATION/TOAST ANIMATIONS
// ============================================

/**
 * Animate notification/toast entry with GSAP
 * Slides and fades in from right
 */
function animateNotificationIn(el) {
    if (!el) return;
    if (typeof gsap === "undefined") {
        el.style.opacity = "1";
        el.style.transform = "none";
        return;
    }

    gsap.killTweensOf(el);

    gsap.fromTo(
        el,
        { autoAlpha: 0, x: 400 },
        {
            autoAlpha: 1,
            x: 0,
            duration: 0.25,
            ease: "power2.out"
        }
    );
}

/**
 * Animate notification/toast exit with GSAP
 * Slides and fades out to right
 */
function animateNotificationOut(el, onComplete) {
    if (!el) return;
    if (typeof gsap === "undefined") {
        el.style.display = "none";
        if (typeof onComplete === "function") onComplete();
        return;
    }

    gsap.killTweensOf(el);

    gsap.to(el, {
        autoAlpha: 0,
        x: 400,
        duration: 0.18,
        ease: "power2.in",
        onComplete: () => {
            if (typeof onComplete === "function") onComplete();
        }
    });
}

// ============================================
// MODAL ANIMATIONS
// ============================================

/**
 * Animate modal opening with GSAP
 * Fades in overlay and scales/slides in dialog
 */
function animateModalOpen(modalEl) {
    if (!modalEl) return;

    const dialog = modalEl.querySelector(".modal-content, .modal-dialog, .folder-modal-content, .admin-modal-content");

    if (typeof gsap === "undefined") {
        if (dialog) {
            dialog.style.transform = "none";
            dialog.style.opacity = "1";
        }
        return;
    }

    gsap.killTweensOf(modalEl);
    if (dialog) gsap.killTweensOf(dialog);

    // Animate backdrop
    gsap.fromTo(
        modalEl,
        { autoAlpha: 0 },
        {
            autoAlpha: 1,
            duration: 0.18,
            ease: "power1.out"
        }
    );

    // Animate dialog if it exists
    if (dialog) {
        gsap.fromTo(
            dialog,
            { y: 16, scale: 0.97, autoAlpha: 0 },
            {
                y: 0,
                scale: 1,
                autoAlpha: 1,
                duration: 0.22,
                ease: "power2.out"
            }
        );
    }
}

/**
 * Animate modal closing with GSAP
 * Reverses the opening animation
 * FIXED: Properly handles callback to prevent freeze
 */
function animateModalClose(modalEl, onComplete) {
    if (!modalEl) {
        if (typeof onComplete === "function") onComplete();
        return;
    }

    const dialog = modalEl.querySelector(".modal-content, .modal-dialog, .folder-modal-content, .admin-modal-content");

    if (typeof gsap === "undefined") {
        if (typeof onComplete === "function") onComplete();
        return;
    }

    gsap.killTweensOf(modalEl);
    if (dialog) gsap.killTweensOf(dialog);

    const tl = gsap.timeline({
        onComplete: () => {
            // Callback executes AFTER animation completes
            if (typeof onComplete === "function") {
                onComplete();
            }
        }
    });

    // Animate dialog out
    if (dialog) {
        tl.to(dialog, {
            y: 10,
            scale: 0.97,
            autoAlpha: 0,
            duration: 0.16,
            ease: "power2.in"
        }, 0);
    }

    // Animate backdrop out
    tl.to(
        modalEl,
        {
            autoAlpha: 0,
            duration: 0.18,
            ease: "power1.in"
        },
        0
    );
}

// Make functions available globally
window.animateAccordionOpen = animateAccordionOpen;
window.animateAccordionClose = animateAccordionClose;
window.animateNotificationIn = animateNotificationIn;
window.animateNotificationOut = animateNotificationOut;
window.animateModalOpen = animateModalOpen;
window.animateModalClose = animateModalClose;

console.log("✨ GSAP UI Animations loaded (v2 - Fixed timing & modal selectors)");
